# The Mathematics of Market Impact and Order Execution

**Impact Kernels, Feasible Policies, and Execution Certificates**  
Miquel Noguer Alonso — Artificial Intelligence Finance Institute (AIFI)  
Final v14, September 14, 2026

Open **main.pdf** for the 116-page manuscript. The active LaTeX source is
main.tex and the four files in sections/. This edition finishes the original
market-impact and execution paper. It contains no added order-book prediction
part, prediction models, or prediction experiments.

The cover retains the original title, author, affiliation and DOI. Version
numbers appear in the package name and revision records, not on the cover.
The bibliography is embedded in main.tex and uses author–year citations.

## What this final revision adds

The original theorem chain connects controlled order flow and clearing to
own fills, a conserved parent ledger, observable feasible policies, and
execution-cost certificates. Sections 29.7–29.8 supply computable finite-model
bounds and a comparison against policies using richer reports.

Theorem 29.26 adds an action-comparison certificate using the same conditional
envelopes. It bounds each action's Bellman disadvantage and propagates that
bound for the implemented controller. It also supports strict action
screening. A summary controller can be exactly optimal even when the full
conditional cost varies within its summary fiber.

Section 33.10 checks the refinement with exact rational arithmetic. The
three controlled-liquidity cases verify 3,711 state–action comparisons and
1,474 strict screening comparisons. The existing cost certificate is sharper
in those cases; the final bound takes the smaller of the two. A separate
two-stage example has a cost certificate of 0.05 USD and an action certificate
of exactly zero. Its randomized version has true regret 0.0875 USD and an
action bound of 0.10 USD.

See audit/FINAL_REVIEW_V14.md for the proof review and precise scope.
Historical reviews and revision records identify their own editions.

## Build

From the project root, with pdfLaTeX, latexmk and the packages in the preamble:

~~~sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
~~~

Figures and generated tables are included, so experiments need not be run
before compiling. For Overleaf, upload the ZIP as a project, select main.tex
as the main document, and use pdfLaTeX. No external bibliography file is
needed. The delivered PDF was built with pdfTeX 1.40.25; a separate Overleaf
build was not performed.

## Reproduce

The verified environment is Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and
Matplotlib 3.10.8. The dependency versions are pinned in requirements.txt.

~~~sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/reproduce.py
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
~~~

On Windows, use .venv\Scripts\python.exe in place of .venv/bin/python.
The ten-script workflow regenerates eleven figures, ten table row files,
numerical macros, stored results and verification reports. It stops on a
failed command or assertion. The complete workflow passed for this edition.

All 33 other pre-existing figure, table and result assets match v13 byte for
byte. The observation-summary JSON gains the action-certificate checks, and
one additional table row file is generated. The earlier numerical values
and supplied wording corrections remain intact.

For the focused exact checks:

~~~sh
python3 scripts/observation_summary_checks.py
~~~

To verify all packaged hashes before rebuilding or regenerating files:

~~~sh
python3 scripts/check_package.py
~~~

Rebuilding can change PDF metadata; regeneration on other numerical
environments can change floating-point bytes. The manifest describes the
delivered package and is not an authenticity signature.

## Verified Lean companion

Appendix E and lean/ retain the previously compiled Lean 4.19.0 /
Mathlib v4.19.0 core. It covers the finite-grid loop identity, the scalar
quartic ray argument and feasible-domain convexity, with the exact declaration
scope in lean/COMPILE.md. Six audited declarations use only propext,
Classical.choice and Quot.sound.

All seven source/configuration hashes match the prior successful clean
kernel-build record in audit/lean_verification.json. Those unchanged sources
were not rebuilt in v14. The general execution certificates and the new
action-comparison theorem are written proofs, not Lean formalizations.

## Package map

| Path | Contents |
| --- | --- |
| main.tex, main.pdf | Final source and compiled manuscript |
| sections/ | Partial-observation and summary-certificate proofs and experiments |
| figures/ | Eleven reproduced figures |
| tables/ | Numerical macro files and ten generated table row files |
| scripts/reproduce.py | Complete numerical reproduction entry point |
| scripts/observation_summary_checks.py | Exact full-history, physical-policy, action-bound and screening checks |
| scripts/partial_observation.py | Belief-grid lower bounds and physical evaluation of the observable controller |
| scripts/orderbook_bridge.py | Tagged FIFO clearing, finite-book control and primitive-rate comparisons |
| scripts/ | Remaining mathematical, ledger, simulation and package-verification code |
| results/ | Parameters, exact fractions, simulations and controller arrays |
| lean/ | Pinned proof sources and build instructions |
| audit/ | Current build, reproduction and provenance records; named historical reviews |
| originals/ | Earlier sources and supplied snippets, including the preserved v13 manuscript |
| MANIFEST_SHA256.txt | Hashes of the packaged files except the manifest itself |

## Interpretation

The results are conditional on the stated model, observable action masks
and error bounds. The finite examples are synthetic. The one-hot signature
controller implements a computed table; the paper does not claim signature
compression or a demonstrated sample-efficiency advantage. Conditional
envelopes must cover every feasible full history and action; constructing
them can be expensive, and a successful fit alone does not validate them.

NYSE and Nasdaq instruction, allocation and auction material is retained
as part of the original execution framework. The mathematical models and
checks do not constitute a full exchange implementation or market calibration.
The DOI is retained from the supplied manuscript; no publication, submission
or DOI-record update was performed.
