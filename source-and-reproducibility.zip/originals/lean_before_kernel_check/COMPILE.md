# Status

Three results, zero `sorry`, zero added `axiom`. **Not yet compiled.** No Lean
toolchain was available in the environment these were written in, and building
Mathlib from source without its cache is not viable there. Everything below is
written to Mathlib conventions but the lemma names and `simp` normal forms have
not been checked against a live Mathlib.

```
# 1. pin Mathlib and match its toolchain
lake update mathlib
cp .lake/packages/mathlib/lean-toolchain lean-toolchain
elan toolchain install $(cat lean-toolchain)
# 2. fetch the Mathlib cache — essential; building from source takes hours
lake exe cache get
# 3. build
lake build
# 4. audit
lake env lean MarketImpactCore/Audit.lean
grep -rn "sorry\|native_decide" MarketImpactCore/    # must print nothing
```

Each `#print axioms` line in the audit must report only `propext`,
`Classical.choice`, `Quot.sound`. Anything else, or `sorryAx`, means the
artifact is not what Appendix E claims.

Only after all four steps pass: open `main.tex`, change `\leanverifiedfalse`
to `\leanverifiedtrue` in the preamble, and rebuild. That single switch turns
Appendix E from "formal statements supplied" into "kernel-checked". Do not
flip it on faith.

# What is here

| File | Paper result | Risk |
|---|---|---|
| `LoopCost.lean` | Theorem 13.1, finite grid; Corollary 13.2 | low — finite linear algebra only |
| `QuarticSign.lean` | Corollary 12.8, ray form | medium — filter lemma names |
| `VenueConvex.lean` | Theorem 27.1 | medium — `ConvexOn` field accessors |

# Where it will break first

1. `Finset.sum_neg_distrib`, `Finset.sum_sub_distrib`, `Finset.sum_add_distrib`
   have churned in Mathlib. If they resolve wrong, `simp [Finset.sum_neg_distrib]`
   → `simp [neg_sum]` or just `push_neg`/`abel`.
2. `Matrix.diag_apply` vs `Matrix.diag` in `trace_mul_expand`. If `simp` stalls,
   `unfold Matrix.trace Matrix.diag Matrix.mul_apply` then `rfl`-adjacent.
3. `eventually_nhdsWithin_of_eventually_nhds` in `QuarticSign` — if absent, replace
   the whole ε-selection block with an explicit witness:
   `ε := min (δ/2) (√(-a₂ / (2*(|a₄| + C + 1))))` and discharge with `nlinarith`.
   Uglier, but it removes the filter dependency entirely.
4. `ConvexOn.2` as the inequality field — in current Mathlib this is the second
   projection of the structure; if the accessor changed, use `ConvexOn.smul_le_sum`
   or destructure with `obtain ⟨-, hineq⟩ := hconv v`.

# Deliberately not included

Corollary 13.3 (admissible cross-impact is self-adjoint). The instantiation at
the rectangular loop `0 → eⱼ → eⱼ+eₖ → eₖ → 0` is a `simp`-normal-form exercise,
not a mathematical one, and guessing it blind would have put a fragile proof next
to two solid ones. Write it once `LoopCost.lean` compiles; it is a short step from
`loop_cost_eq_area_pairing`.

Nothing from §17 or §29. Those certificates need Schwartz kernels and POMDP value
iteration; formalising them means building infrastructure, not checking results.
That is a different project and should not be promised in this paper.

# What the paper currently claims

Appendix E is gated by `\ifleanverified` in `main.tex`. As shipped the switch
is OFF and the appendix says the formal statements are supplied and the kernel
check is not part of this version. That is true today. Flip it only when it
stops being true.
