# Revision v11 — requested wording refinements

Date: September 14, 2026

This revision applies the three supplied LaTeX edits to the completed v10
manuscript. The manuscript's existing calligraphic cost notation is retained.

1. Assumption 12.2 is renamed **Truncation consistency**, with label
   `ass:trunc`. Its counterexample now explicitly says the condition is stronger
   than causality. Theorem 12.5 and its proof use the new name; no references to
   the former label remain in the current manuscript. The distinct causal
   cross-impact discussion in Section 10.1 is preserved.
2. Section 33.5 states the USD 0.0402 difference, names the belief policy's
   reported USD 0.078 Monte Carlo standard error, and expresses the difference
   as 0.51 of that standard error. The supplied `tab:policies` label already
   identifies Table 12 and is used directly.
3. Section 32.6 states that the two Nasdaq prices tie at 800 matched shares and
   identifies 400 shares of excess demand at USD 100.01 and 300 shares of excess
   supply at USD 100.02. The smaller imbalance selects USD 100.02. The subsequent
   allocation explanation is retained.

The extra wording changes pagination to 97 pages. An explicit page break before
Part VIII keeps its contents entry and hyperlink on the page bearing its title.
No other manuscript text was changed.

## Verification

- A complete pdfLaTeX/latexmk rebuild passed without undefined references or
  citations, duplicate labels, or overfull boxes. The nine existing underfull-box
  notices remain.
- Assumption 12.2, Theorem 12.5, and Table 12 resolve to the intended items.
- The stored belief-policy mean is 10.14932275 and the coarser-grid value is
  10.109134201203524. Their difference is 0.040188548796476, which rounds to
  0.0402. The stored Monte Carlo standard error is 0.07819837472941124; the ratio
  rounds to 0.51 and the standard error rounds to 0.078.
- The auction table contains demand/supply pairs 1200/800 and 800/1100 at the
  tied prices, confirming the stated imbalance directions and quantities.
- The edited assumption, theorem, proof, auction paragraph, numerical paragraph,
  table reference and contents entry were inspected in rendered pages. The
  downstream page flow was also inspected.
- All files in `figures/`, `results/`, `tables/`, and `scripts/`, as well as
  `requirements.txt`, are byte-identical to v10. The complete numerical
  reproduction passed in v10; unchanged experiments were not rerun for this
  wording revision.

The v10 source and its build/provenance records are preserved under `originals/`
and historical filenames in `audit/`. The current build and provenance records
describe v11. The manifest records the delivered package.
