# Deep technical review: final v12

**The Mathematics of Market Impact and Order Execution**  
Miquel Noguer Alonso | Review dated 14 September 2026  
Reviewed edition: final v12 with the verified Lean companion, 108 pages.

## 1. Assessment

**My assessment is A- as a research monograph. I would not call this A+ yet.** This is a qualitative editorial judgment, not a prediction of journal acceptance. The mathematical framework is substantial, the assumptions are unusually explicit, and the numerical package reproduces. I did not find a fatal defect in the central execution-certificate arguments. I found one definite formula correction, one qualification needed in the general belief-grid construction, and one author-name citation error.

The main obstacle to a stronger assessment is the contribution hierarchy. The abstract foregrounds an analytic Taylor hierarchy and the permanent-impact area identity. Both are useful organizing results, but their core mathematical mechanisms are familiar. The more distinctive work is the combination of controlled observations, exact feasibility, policy approximation, physical evaluation, and computable execution-loss bounds in Sections 17 and 29. Those results deserve the headline position.

For a theory monograph, the absence of real-market data is not a defect by itself. The manuscript correctly limits its empirical claims. For a research article claiming an advance in execution algorithms, the current experiments leave an important question unanswered: what useful computational or decision advantage comes from the proposed signature representation, beyond a conventional controller using the same sufficient state?

**Recommendation:** retain the mathematics and reproducibility package, correct the localized issues, sharpen the main claim, and strengthen one decisive comparison. This calls for focused revision of positioning and evidence, rather than wholesale replacement of the proofs.

## 2. What was checked

I worked from the exact final v12 source archive and its embedded `main.pdf`, read the main source and both partial-observation sections, audited the central proofs and implementation, and checked the closest literature against primary sources. The separately delivered PDF has identical extracted text on all 108 pages. Relevant rendered pages, including the information theorem, the global certificate, and the numerical certificate table, were visually inspected.

The archive's 118 manifest entries match. I reran the complete nine-script numerical workflow in a separate copy. It passed, and **all 32 generated files in `results/`, `tables/`, and `figures/` match the delivered files byte for byte**.

I also wrote an independent rational-arithmetic check that reconstructs the small hidden-liquidity problem directly from the manuscript's action and cost specifications. It reproduces the exact three-stage optimum. A separate comparison checks the implementation's primitive probabilities and 73,800 outward enclosures of probability/interpolation weights over 24,600 grid-outcome cases.

The existing Lean build record and its seven recorded source/configuration hashes were checked against the delivered files. This review did **not** perform another clean Lean kernel build. The earlier successful build remains recorded evidence; the current review adds source inspection and hash matching. Numerical agreement does not prove the general theorems, and a focused literature comparison does not establish exhaustive priority over all related work.

## 3. Corrections to make

### C1. Gaussian information value needs an absolute value

**Location:** Theorem 18.2, page 34; proof on page 35; label `thm:ledgerlower`.

For conditional signal laws with means zero and epsilon, the theorem gives the saving as:

$$\Delta[\Phi(\varepsilon/2)-1/2].$$

No nonnegative restriction on epsilon is stated. The saving must be invariant under reversing the sign of the mean shift. The correct general expression is:

$$\Delta[\Phi(|\varepsilon|/2)-1/2].$$

For epsilon = -1 and Delta = 1, the printed expression is approximately **-0.1914624613**, while the actual value of information is **+0.1914624613**. This is a direct counterexample to that sentence as written. It does not invalidate the binary total-variation identity, the information ceiling, or the positive-shift asymptotics.

The simplest repair is to insert the absolute value and clarify that the likelihood-ratio test reverses its inequality when epsilon is negative. Alternatively, explicitly assume epsilon is nonnegative.

```latex
For conditional Gaussian laws $\mathcal N(0,1),\mathcal N(\epsilon,1)$,
the saving is $\Delta[\Phi(|\epsilon|/2)-1/2]$ and
$I=\epsilon^2/8+o(\epsilon^2)$.
```

### C2. The uniform grid does not accommodate every stated initial prior

**Location:** Section 29.7, pages 63-64; Assumption 29.16 and the paragraph before equation (29.32).

The assumption allows a known initial belief anywhere in the unit interval. The construction then asks for the uniform grid `{0, 1/m, ..., 1}` to contain that belief. An irrational prior cannot satisfy this requirement for any integer m. Even a rational prior requires a compatible sequence of grid sizes.

This is a **generality qualification**, not a counterexample to the certificate for a grid containing the initial prior. The experiment uses one half and compatible grids, so its results are unaffected.

Two clean repairs are available. Restrict the statement to rational initial priors and compatible grid sequences; or add the initial prior to the grid. In the latter formulation, express the proof using the maximum cell width. The rounding and interpolation bounds remain valid when that width is at most 1/m. Update the summary dimension from `|X|(m+1)` to `|X||G_m|`, which is at most `|X|(m+2)` for the augmented grid. This avoids silently charging an unaccounted initial rounding error.

### C3. Preserve the compound surname Abi Jaber

**Location:** Section 10.2, page 17; bibliography entry `abijaberneuman2022`.

The body prints **Jaber and Neuman (2025)** because the optional `bibitem` label splits the compound surname incorrectly. Use **Abi Jaber and Neuman (2025)** and alphabetize consistently. The listed authors are Eduardo Abi Jaber and Eyal Neuman. [Author-submitted article record](https://arxiv.org/abs/2211.00447).

```latex
\bibitem[Abi Jaber and Neuman(2025)]{abijaberneuman2022}
Eduardo {Abi Jaber} and Eyal Neuman.
```

## 4. The main research revisions

### R1. Put the strongest contribution first

**Locations:** abstract, page 1; reading guide, page 5; comparison in Section 29.8, pages 67-68.

Theorem 12.5 starts with Banach-space analyticity. Taylor expansion, symmetry, and the distributional kernel representation then do much of the work. Theorem 13.1 gives an effective geometric account of linear permanent cross-impact, but its basic mechanism is the decomposition of a linear one-form into an exact symmetric part and an antisymmetric area part. Neither should bear the full burden of an originality claim.

The strongest coherent contribution is a chain with a clear economic output: tagged controlled order flow produces fills and reports; the policy uses the correct observation history and exact feasibility masks; model and policy errors become bounded execution loss; a finite-observation specialization supplies a computable stopping certificate.

Section 29.8 already states the relationship to prior work responsibly. Move that clarity into the abstract and introduction. Distinguish established foundations, constructions developed in this manuscript, and claims whose computational effectiveness remains to be shown. For a monograph, keep the foundational material as an organized route into the main results. For a journal version, substantially reduce that material in the main argument.

### R2. Separate signature implementation from evidence of signature advantage

**Locations:** Corollary 29.20, pages 66-67; Sections 33.8-33.9, pages 88-92.

The one-hot construction is mathematically valid. At the finest partial-observation grid, its summary dimension is **11,275**, with **135,300 stage-specific preferred-action entries**. Its first signature level identifies the already-computed observable state and rounded belief. Applying linear scores to this vector implements a table.

Consequently, the experiment demonstrates that a certified finite-memory controller can be represented and sampled as the specified signature-softmax policy. It does not demonstrate compression, superior sample efficiency, a beneficial higher-order path feature, or a better optimization method than the underlying belief-grid computation. The manuscript acknowledges the growing dimension; this is a limit on the evidence, not a hidden mathematical error.

The strongest next experiment would use the same controlled model, observations, action masks, costs, and optimal-value bounds to compare a compact transcript-signature policy with a conventional state/belief policy and a standard POMDP approximation. Report true cost, certified gap where available, parameter count, runtime, and behavior as the state space grows. The one-hot policy should remain a transparent reference implementation.

The existing frozen-prior and action-independent-transition baselines are useful misspecification experiments. They do not isolate the benefit of the signature representation. Their optimization models deliberately differ from the physical model, as the manuscript correctly explains.

### R3. Keep the two kinds of global claim visibly separate

**Locations:** Theorem 29.10 and Corollary 29.11, pages 60-61; Theorem 29.18, page 65.

The general transcript result has a vanishing signature-class gap under finite actions, bounded loss, complete observable histories, and the stated marked-event assumptions. The consistency result additionally needs vanishing model error and certified global optimization tolerance. It does not give a general depth-versus-accuracy rate or an algorithm that finds those globally near-optimal coefficients.

The finite-observation, binary-hidden-state result has a different strength: it computes lower and upper bounds by finite recursions and evaluates a feasible controller in the physical hidden-state model. It therefore provides an actual stopping certificate for that model.

These are complementary results with different scopes. The second does not automatically certify the unrestricted policy problem on an original continuous-time transcript after timestamps or reports have been discarded. Section 29.7 correctly warns about this. A stronger bridge would prove sufficiency of a finite observation reduction in a concrete marked-book model, or add a bound for the decision loss caused by that reduction.

### R4. Explain what limits a useful certificate after model estimation

**Locations:** Corollary 29.6, page 57; equation (29.40), page 66; Tables 14 and 17, pages 87 and 90.

The small planning gap is impressive numerical evidence about a specified finite model. Deployment under an estimated model additionally requires the fixed-policy model discrepancy bound. Equation (29.40) makes the distinction explicit: the transferred guarantee contains **twice the model-error bound plus the computed planning gap**.

For illustration, if a justified fixed-policy model discrepancy bound were one cent, the deterministic controller's transferred regret bound would be approximately **$0.0200002413**, despite its much smaller planning gap. This is a hypothetical arithmetic example, not an estimate of market error.

The primitive-rate bound can also be conservative. In the 19-state book, optimizing at sell rate 1.4 and evaluating at the true rate 1.2 gives regret about **$0.025897**, versus a bound of **$0.725077**. At larger errors the bound reaches the full loss range. In the partial-observation example the finest-grid uniform mesh bound is **$1.090546875**, versus a computed gap of roughly **$0.0000002413**.

These facts do not undermine validity. They identify where another substantive contribution could lie: sharper bounds adapted to occupancy or decision sensitivity, or a defensible statistical procedure for the uniform primitive-error assumption. The current finite-sample moment bound is a separate result for bounded, fixed exogenous features; it does not supply a general estimator guarantee for controlled book intensities.

### R5. Make one comparison decisive, rather than adding more breadth

The 108-page length is defensible for a monograph. Its risk is that many elementary propositions, mechanism descriptions, and separate examples compete with the results that deserve close attention. A skeptical referee should be able to identify the precise claim added to the literature in a few pages.

A useful target is one model containing a nontrivial queue or reservation state, hidden liquidity, action-dependent observations, and a feasible completion mechanism, with an explicitly bounded optimum. Use it to establish either a practical gain from a compact policy representation or a new quantitative approximation result. Real-market data are necessary for a market-performance claim; they are not necessary for a rigorous theory contribution of this kind.

## 5. Contribution against the closest foundations

The comparisons below concern mathematical scope. They do not rank researchers or infer priority from the breadth of a manuscript.

| Prior foundation | What was already established | Defensible distinction in v12 |
| --- | --- | --- |
| Cont, Degond and Xuan (2025) | Order flow, deterministic clearing, and generator factorization; their Proposition 3.6 gives the factorization used here. | Ownership, private reports, a conserved parent ledger, controlled event laws, and an execution-loss certificate in the declared finite setting. This specializes and extends an execution use of their framework; it does not replace it. |
| Cont and Kukanov (2017) | Joint market/limit placement across exchanges with queue-dependent fills, execution risk, fees, and a stochastic optimization method for a scheduled slice. | A multi-stage parent problem with controlled learning, reservation accounting, and separate model/policy error accounting. Generic venue allocation or the relevance of queues is not new. |
| Kalsi, Lyons and Perez Arribas (2020) | Signature execution policies, expected-signature objectives, and approximation of transient impact. | Exact finite-degree exponential augmentation, the explicit completion-preserving feature transformation, and a cost-unit perturbation certificate on a common feasible coefficient set. |
| Bank et al. (2025) | Density of signature controls and equality of optimal values under driver-filtration and rough-dynamics hypotheses. | Masked finite-action approximation on endogenous observable transcripts, with a proof using bounded-loss sequential coupling. The general density principle is inherited; the observation/control setting and proof route are the distinction. |
| Classical POMDP planning | Belief-value geometry and computable grid bounds predate this manuscript. | A complete feasible execution controller, physical hidden-state evaluation, numerical enclosures, and model transfer assembled into an auditable calculation. |

The first two rows are grounded in [Cont, Degond and Xuan, Proposition 3.6](https://arxiv.org/pdf/2302.01169) and [Cont and Kukanov, Sections 1-3](https://arxiv.org/pdf/1210.1625). The latter is particularly important when explaining a contribution “against Cont”: the 2017 placement paper is a closer execution comparator than the 2025 book-factorization paper alone.

[Kalsi, Lyons and Perez Arribas, Example 3.5 and Section 4](https://arxiv.org/pdf/1905.00728) already discuss exponential transient impact and signature objectives. Their example presents transient impact through arbitrary-accuracy approximation. Exact augmentation and feasibility/error accounting are therefore the narrower comparison to defend.

[Bank et al., Proposition 4.5, Theorem 4.7, and the related-literature discussion](https://arxiv.org/html/2406.01585v2) distinguish their driver-based open-loop construction from the difficulty of control-dependent information in feedback formulations. V12's restricted observed-history theorem addresses a meaningful part of that difficulty. It should be described with its finite-action, finite-decision, bounded-loss scope intact.

[Lovejoy (1991)](https://pubsonline.informs.org/doi/abs/10.1287/opre.39.1.162) already constructs grid-based value bounds and bounds the loss of approximate POMDP policies. V12 appropriately credits this foundation. Its stopping certificate should be presented as a carefully specified execution construction, not the first computable certificate under partial observation.

A further literature check before submission should include [Aqsha, Bank and Sanchez-Betancourt (2026)](https://arxiv.org/abs/2602.23473), whose preprint studies deterministic convex quadratic optimization of signature controls for LQ problems. Its abstract is close enough to the broad quadratic-objective theme to merit comparison. I did not establish that it subsumes v12's exponential augmentation or completion transformation, and it is not evidence that those specific constructions are already proved elsewhere.

## 6. Mathematical audit of the central arguments

| Result or component | Assessment from this review | Important boundary |
| --- | --- | --- |
| Linear energy, exponential optimum, Riesz equilibrium | The normalizations, potential conditions, endpoint treatment, and limiting cases checked out. | Conditional PSD on round trips is distinguished from full PSD; positivity alone does not prove attainment. |
| Theorem 12.5 and Corollary 12.8 | The analytic expansion and necessary quadratic/quartic sign argument are coherent under the assumptions. | Analyticity is an assumption; the quartic condition is necessary, not a general sufficiency theorem. |
| Analytic crossover construction | The local quadratic behavior and large-size subquadratic law are compatible. Strictly increasing transformation preserves minimizers where they exist. | This constructs a model; it does not derive or identify a market size law. |
| Permanent and transient cross-impact geometry | The orientation and factor in the area pairing are consistent. The transient decomposition retains its energy and endpoint terms. | Zero loop cost in one asset is a linear permanent-impact statement in the specified frictionless model. |
| Manipulation defect and phantom profit | The normalization by gross volume and factor one half in profit are consistent. The Lipschitz perturbation bound has the stated scope. | Repairing a grid defect does not automatically improve estimation accuracy or prove continuum admissibility. |
| Exact signature objective and completion features | The shuffle/augmentation construction, degree accounting, zero-integral completion features, and coefficient feasibility bounds are coherent. | The exogenous feature law and fixed feasible coefficient set are essential. The class may be conservative. |
| Information ceiling | The Bayes-envelope, total-variation and Pinsker argument gives the stated upper bound and sharp binary rate. | Apply correction C1 to the Gaussian example. Information irrelevant to the loss can have zero value. |
| Nash operator and discretization results | The coercive game argument and the bounded-kernel weak-star comparison retain the needed conditions. Singular cell self-energy is not discarded. | No unconditional continuum existence or unrestricted nonlinear manipulation theorem follows. |
| Primitive marked-path coupling | The dummy mass, physical marks, reports, and common-policy requirement are accounted for correctly. | Changed deterministic mechanisms, interventions, initial laws, or observation maps require their own error accounting. |
| Theorem 29.10 | Complete initial/action/report histories, score approximation, exact masks, and forward hybrid measures address the central filtration problem. | This proves an approximation statement, not a general tractable global-training algorithm. |
| Theorem 29.18 and Proposition 29.19 | Concavity gives the lower relaxation; physical hidden-state evaluation gives an implementable-policy upper bound. The forward resampling comparison supports the mesh argument. | The proof's resampling model is not the deployed environment. Correction C2 clarifies which initial priors the grid covers. |
| Venue aggregation, reservation accounting, terminal conditions | Convex aggregation, KKT directions, the reservation invariant, and declared terminal facilities are consistent. | Exact asynchronous accounting requires authoritative reports. Guaranteed terminal execution remains an explicit model assumption. |

The strongest proof detail in the new partial-observation section is the separation of the rounded belief used by the controller from the physical hidden state used in evaluation. Redrawing liquidity from the controller's rounded belief would evaluate another environment. V12 avoids that error in both equation (29.35) and the implementation.

The general transcript proof likewise does something necessary: it retains initial information and past actions, enforces feasibility through exact masks, and compares policies under the laws generated by earlier replacements. A density assertion based only on a fixed uncontrolled history distribution would not supply the same conclusion.

## 7. Numerical findings

The full reproduction passed. Selected results from the fresh run are:

| Quantity | Reproduced result |
| --- | --- |
| Finest belief grid | 1,025 nodes; 12 stages; 7 instructions; parent of 10 units, each 100 shares |
| Lower bound on the unrestricted finite-model optimum | $16.48417271399559 |
| Deterministic controller cost enclosure | [$16.484172955266253, $16.48417295526637] |
| Deterministic global planning-gap bound | $2.412707793553182 × 10⁻⁷ |
| Finite-score controller, preferred weight 1,048,576 | Global gap at most $3.594321585964622 × 10⁻⁵ |
| Independent exact small problem | 232172138011 / 156250000000 = 1.4859016832704; 3,553 cached states |
| Independent grid checks | 24,600 outcomes; 73,800 probability/interpolation-weight enclosures |
| Reproduced result/table/figure files | 32 of 32 byte-identical |

The lower bound encloses the unrestricted optimum for the specified observation problem. The controller's upper bound is a feasible-policy value. Their difference is therefore substantially stronger evidence than a small difference between adjacent grid solutions or a Monte Carlo mean within one standard error.

The manuscript also correctly separates the deterministic preferred-action controller from the finite-score randomized controller. They have different certified gaps. The smaller deterministic number should not be assigned to the softmax controller.

The six-case horizon/prior sensitivity table supplies useful checks, but it varies a limited subset of the synthetic model. It does not demonstrate robustness to omitted queue structure, observation coarsening, latency, unknown hidden-state dimension, or an estimated response law. These are extensions of the evidence, not failures of the reported arithmetic.

## 8. Earlier requested fixes, institutional details, and Lean scope

The three earlier wording changes are present in the final PDF. Assumption 12.2 is **Truncation consistency** on page 19, and the theorem/proof use the corrected term. The separate causal cross-impact notion remains distinct. Section 33.5 on page 84 identifies the **$0.078 Monte Carlo standard error of the belief policy in Table 12**. Section 32.6 on page 78 identifies **400 excess-demand shares versus 300 excess-supply shares** at the tied Nasdaq prices.

The ordinary Nasdaq tie-break discussion is consistent with the volume, unmatched-interest, entered-price, and midpoint sequence in the rule text; the simple all-MOC/LOC example selects $100.02 and 800 matched shares. The manuscript appropriately distinguishes that unrestricted example from restricted classes and special protection branches. [Nasdaq Equity 4, Rule 4754(b)(2)](https://listingcenter.nasdaq.com/rulebook/nasdaq/rules/nasdaq-equity-4).

The NYSE discussion correctly distinguishes filing effectiveness from implementation of the D Order change. The cited release provides for an implementation date announced by Trader Update, anticipated by the first quarter of 2027. This supports the manuscript's warning against applying the amendment retroactively. This was a focused source check, not an exhaustive audit of every live exchange rule. [SEC Release 34-106126](https://www.sec.gov/files/rules/sro/nyse/2026/34-106126.pdf).

The Lean companion supports the finite-grid loop identity, the scalar ray sign argument, and convexity of the venue value on feasible quantities. The corrected venue hypothesis only requires a greatest lower bound where the cost set is nonempty. The accompanying consistency lemmas prevent the earlier infeasible-domain assumption from being mistaken for a substantive theorem.

The recorded six declarations use the stated standard logical axioms. The companion does not formalize the continuum arguments, the general signature-control certificates, the physical evaluation algorithm, venue attainment/KKT, or the market interpretation. Appendix E states this scope well. Keep that precision wherever the formal verification is advertised.

## 9. Recommended next revision

1. **Correct C1-C3.** They are small, reviewable edits. C1 needs a matching proof sentence; C2 should preserve the existing experiment and make the general theorem's prior/grid relationship explicit.
2. **Rewrite the contribution opening.** Lead with controlled observations, feasible policies, and the computable execution certificate. Present the Taylor and area results as structural foundations unless a more specific originality claim is established.
3. **Bring the closest comparisons forward.** Include Cont and Kukanov alongside Cont, Degond and Xuan; retain the explicit Kalsi, Bank, and classical POMDP distinctions.
4. **Choose one substantive upgrade.** Either prove a quantitative approximation/reduction result beyond the current existential theorem, or demonstrate useful compact-policy performance against a strong correctly specified comparator under the same observation and feasibility conditions.
5. **Preserve the audit discipline.** Keep model error, planning error, sampling uncertainty, and formal-proof scope separate. Reproduce the relevant assets after the substantive change and update the edition's manifest.

Correcting a sign and polishing the prose will make v12 cleaner. A stronger headline result, or a decisive demonstration of its usefulness, is what would justify moving the research assessment toward A+.

## Appendix: review evidence

The companion evidence archive contains this report's editable Markdown, the independent checker and its JSON output, the fresh reproduction log, and the 32-file comparison record. Run the checker with Python and NumPy against an extracted copy of the final source package:

```sh
python3 reviewer_checks.py /path/to/Market_Impact_Execution
```

The reviewed archive SHA-256 is:

```text
277cc78b466475b4435eb99290ba0d949f458436190a4169e542ac2a2c0330d0
```

The canonical PDF embedded in that archive has SHA-256:

```text
fdad5cb48b0a86773516ef959b76f775d22cfd09e84383324f56a3874dc0e1f7
```

The manuscript was not edited as part of this review.
