# Final v12: verified Lean core

This revision repairs and verifies the Lean companion in the uploaded
`files - 2026-09-14T075319.237.zip`, then rebuilds the manuscript and replaces
its stale build records. The unmodified Lean files and manuscript source
are preserved under `originals/`; the uploaded audit description is preserved
as `FINAL_V12_LEAN_before_kernel_check.md`.

## Changes

1. Pin Lean 4.19.0, Mathlib v4.19.0 and the full dependency manifest. Repair
   missing and invalid imports, real-number noncomputability declarations,
   a redundant rewrite, and the continuity proofs used in the ray argument.
2. Correct `value_convex`: require a finite greatest lower bound only at
   feasible quantities. The uploaded hypothesis required one for every
   real quantity, including negative infeasible quantities whose empty cost
   sets have no real greatest lower bound. It was therefore unsatisfiable.
   Require venue convexity on capacity intervals, as in the manuscript.
   Verify convex combinations of feasible splits and two zero-cost
   consistency lemmas. Do not add an attainment or KKT claim.
3. Compile all three modules from a clean project build. Audit four principal
   declarations and the two consistency lemmas. Every reported dependency
   set is exactly `{propext, Classical.choice, Quot.sound}`. The build has no
   warnings or errors, and the active source scan finds no admission or
   unsafe-proof tokens. See `lean_verification.json` and the two Lean logs.
4. Enable Appendix E's verification statement only after these checks.
   State its finite-grid, scalar-remainder and feasible-domain limitations
   precisely. Remove the unsupported assertion about what infrastructure
   currently exists in Mathlib.
5. Correct the supplied forward-reference scanner to split multi-label
   `cref` groups. It reports no undefined labels. Its 60 long forward
   references are an advisory distance count, not a compilation failure;
   reading-guide cross-references intentionally point ahead.
6. Rebuild the PDF, review the changed pages and regenerate current page,
   reference and hash records. All 32 numerical figure, table and result
   assets remain byte-identical to the uploaded package.

## Verification scope

The kernel verifies the supplied formal statements. The continuum Stokes
statement, the analytic-functional assumptions, venue attainment/uniqueness/
KKT conclusions, the self-adjointness converse, execution certificates and
numerical experiments are outside this companion. This is not verification
of the full monograph or validation of a market model.

The environment-specific executable-path accommodation and its source are
recorded under `environment/`. The official Lean kernel and Mathlib tracked
sources were not modified. No external publication was performed.
