# Deep review of the v8 additions

**Verdict.** The three-point defect formula and the phantom-profit corollary
are mathematically correct under their stated normalization and properly
restricted domains. The proposed coefficient error is not present in the
actual manuscript. The raw snippets contain two inaccurate descriptions:
the defect is not globally a linear functional, and admissible projection
does not have a predetermined effect on the execution-regret bound. The
integrated revision corrects both and makes the trading constraints explicit.

This review compares `aplus_snippets_v8.tex` with the latest 79-page source
and checks its interaction with the energy convention, Theorem 6.1,
Definition 14.1, Proposition 14.2, Example 14.4, Section 21 and Proposition
29.1. It also checks the revised proofs and relevant numerical calculations.
It is a focused mathematical review of these additions and dependencies,
not a new proof-by-proof audit of every result in the full manuscript.

| Item | Assessment | Importance |
| --- | --- | --- |
| T1: inverted coefficients | Incorrect diagnosis; the baseline already has 2/5 and 3/10. | Correct the revision record, rather than claiming a nonexistent numerical repair. |
| T2: exact defect | Correct for G0 >= G2 on the specified three-point grid. | Useful explicit diagnostic and a clear strengthening of the worked example. |
| T2: admissibility threshold | Correct for absence of negative-cost round trips. | Does not imply full PSD, continuum admissibility, or one-directional mandate execution. |
| T2: linearity description | Incorrect in the supplied remark. | The positive-part operation makes the formula piecewise linear. |
| T2: Lipschitz constant | Correct and exactly sharp on this grid. | An explicit attaining perturbation supplies the missing sharpness argument. |
| T3: phantom gain and error bound | Correct, including the factor one half. | Requires the gross-volume convention and an impact-only comparison over signed round trips. |
| T3: projection and regret | The raw wording is too categorical. | Projection eliminates the tested defect but may increase or decrease the entrywise error used by the regret bound. |
| Grid monotonicity | Requires nested grids under a common kernel. | Increasing the final time while changing the sampled times is not enough. |

**The coefficient check.** The baseline source contains

```tex
\mathcal E_G[\nu]=\tfrac25(u-v)^2-\tfrac3{10}(u+v)^2
```

In TeX, `\tfrac25` takes 2 as its first argument and 5 as its second:
it is 2/5. Likewise, `\tfrac3{10}` is 3/10. The source never had the
claimed coefficients 5/2 and 10/3. The integrated version writes both
arguments explicitly and introduces p and d, which improves readability.

For G = (1, 19/20, 1/5), direct matrix multiplication gives

\[
K=\begin{pmatrix}
1&19/20&1/5\\
19/20&1&19/20\\
1/5&19/20&1
\end{pmatrix},\qquad
\mathcal E_G(u,-u-v,v)=\frac25(u-v)^2-\frac3{10}(u+v)^2.
\]

The unnormalized trade (1,-2,1) has energy -6/5 and cost -3/5. Its gross
volume is 4. Dividing the trade by 4 gives energy -3/40 and TV norm 1.
Thus the defect 3/40 and volume-four profit 3/5 were already consistent.

**The general three-point proof.** Every zero-mass vector is
\(\nu=(u,-u-v,v)\). Direct expansion, before changing variables, is

\[
\mathcal E_G[\nu]
=2(G_0-G_1)(u^2+v^2)+2(G_0-2G_1+G_2)uv.
\]

Setting p = u + v and d = u - v gives

\[
\mathcal E_G[\nu]
=\frac{G_0-G_2}{2}d^2
+\frac{3G_0-4G_1+G_2}{2}p^2.
\]

The exact constraint in these coordinates is

\[
\|\nu\|_1=\max(|p|,|d|)+|p|\leq1.
\]

Consequently |p| <= 1/2. If G0 >= G2, replacing d by zero preserves
feasibility and cannot increase energy. Minimization then reduces to
one scalar quadratic on [-1/2,1/2]. If its coefficient is nonnegative,
the minimum is zero. Otherwise its minimum is achieved at p = +/-1/2.
This proves

\[
\boxed{\delta_T(G)=\frac{(4G_1-3G_0-G_2)^+}{8}.}
\]

No monotonicity, nonnegativity or nonsingularity assumption beyond
G0 >= G2 is needed for this algebraic result. The condition G0 >= G2
cannot simply be dropped: G = (0,0,1) has actual defect 1/2, attained
by (1/2,0,-1/2), whereas the displayed positive-part formula would give
zero. If G0 = G2, the stated attaining vectors remain valid but need
not be the only minimizers. The snippets correctly avoid claiming uniqueness.

Discrete convexity gives 2 G1 <= G0 + G2, hence
4 G1 <= 2 G0 + 2 G2 <= 3 G0 + G2. The last inequality is strict if
G0 > G2. Thus the sufficiency argument and all three displayed sampled
examples are correct. The threshold only tests the declared three-point
energy form; it does not characterize an arbitrary interpolation or a finer grid.

**What zero defect does not imply.** There are two distinct optimization
questions: whether a zero-net-trade loop has negative cost, and whether
adding opposite-direction trades makes a nonzero mandate cheaper. The
defect answers the first. The distinction between kernel positivity and
the behavior of optimal schedules is also explicit in the established
matrix-kernel theory; positive definiteness alone is not the full condition
for nonoscillatory optimal trading. See the introduction and Section 2 of
[Alfonsi, Klöck and Schied, author manuscript](https://arxiv.org/pdf/1310.4471).

A direct example uses the snippets' own nonconvex, zero-defect kernel
G = (1,7/10,1/5). For a unit buy, symmetry reduces the signed optimization
to x = (a,1-2a,a), with cost

\[
C(a)=\frac12-\frac35a+\frac25a^2.
\]

The signed minimum is at a = 3/4, with trade (3/4,-1/2,3/4) and cost
11/40. The buy-only restriction forces 0 <= a <= 1/2, giving trade
(1/2,0,1/2) and cost 3/10. Allowing an intermediate sale reduces cost
by 1/40 even though every zero-mass loop has nonnegative cost. The
signed optimum has constant potential (11/20,11/20,11/20); the buy-only
optimum has potential (3/5,7/10,3/5), verifying both stationarity conditions.
This example is now included in Remark 14.6.

At the threshold G = (1,4/5,1/5), the same unit-mass family has
C(a) = 1/2 - 2a/5. Without a gross-volume cap, its infimum is minus
infinity as a grows, although the round-trip defect is zero. There is no
contradiction: the cross term with a nonzero mandate can act along a
zero-energy direction. This reinforces the manuscript's existing distinction
between round-trip admissibility and existence of a signed mandate optimum.
The finite gross-volume assumption in Proposition 29.1 and Corollary 29.2
prevents this unbounded-volume construction.

**The Lipschitz and linearity claims.** The formula is the positive part
of a linear contrast divided by eight. It is convex and piecewise linear;
it is not a linear functional on the full stated domain. On the active
region its gradient in (G0,G1,G2) is (-3,4,-1)/8, whose l1 norm is 1.
That proves the upper Lipschitz constant in the uniform norm but should
be supplemented by attainment to claim exact sharpness.

Take G = (1,0.95,0.2) and H = G + h(-1,1,-1), with 0 < h < 1/40.
The perturbed kernel remains nonnegative and nonincreasing, and

\[
\|H-G\|_\infty=h,
\qquad \delta_T(H)-\delta_T(G)=h.
\]

Thus the fixed-grid constant is exactly 1. The integrated manuscript
contains this attaining pair.

There is a further exact consequence on this three-point domain. If
d = delta_T(G), then H = G + d(1,-1,1) preserves G0 - G2 and reduces
4 G1 - 3 G0 - G2 by 8d. Therefore H is round-trip admissible and its
uniform distance from G equals d. Combined with Proposition 14.2,

\[
\operatorname{dist}_\infty(G,\mathcal G_{\{0,1,2\}})=\delta_T(G)
\quad\text{when }G_0\geq G_2.
\]

This is a result derived in the review, restricted to the fixed-grid
admissible cone. It does not establish equality for general grids or
continuum kernels. For the worked kernel, a nearest admissible repair is
(43/40,7/8,11/40), at distance 3/40.

**The phantom-profit proof.** For Q > 0, x = Q nu is a bijection between
zero-net-trade vectors with gross volume at most Q and the TV-unit
comparison set used by the grid defect. Quadratic homogeneity gives

\[
\sup_{\mathbf 1^Tx=0,\ \|x\|_1\leq Q}
\left(-\frac12x^T\widehat Kx\right)
=\frac12Q^2\delta_T(\widehat G).
\]

Q = 0 is immediate, and finite-dimensional compactness ensures attainment.
The one-half factor comes from the manuscript's execution-cost convention,
not from a second normalization of TV. For a true matrix with nonnegative
zero-mass energy and maximum entrywise error epsilon_K,

\[
-\nu^T\widehat K\nu
\leq \nu^T(K-\widehat K)\nu
\leq \epsilon_K\|\nu\|_1^2,
\]

so the phantom-profit bound follows. This proof only needs a symmetric
matrix and the correct zero-net-trade constraint. The scalar sampled-kernel
notation is valid in the integrated corollary because it explicitly fixes
a single-asset time grid.

The coefficient is sharp. Let G = (1,4/5,1/5) and
Ghat = G + h(-1,1,-1). The true grid defect is zero, the estimation
error is h, and the estimated defect is h. The scaled trade
Q(1/4,-1/2,1/4) attains estimated gain Q squared times h divided by two,
while its true impact cost is zero.

The economic interpretation requires four qualifications, now stated or
retained in the manuscript. Q is gross traded volume, not merely net
parent size. The supremum permits all signed round trips; a constrained
execution policy may attain less, and a buy-only policy has only the zero
round trip. The calculation concerns the impact component, excluding
other charges. The regret comparison uses common feasible policies and a
common controlled law of fills and observations; if impact misspecification
also changes that law, its error needs an additional term.

If the fitted kernel is random, these are deterministic statements for a
realized estimate or on an event where its error bound holds. The corollary
does not by itself provide a statistical confidence guarantee for epsilon_K.
For multiple assets, net-zero constraints must be imposed separately for
each asset; one scalar sum across unrelated asset quantities is insufficient.

**Projection does not determine the regret bound.** A useful exact
counterexample uses Euclidean projection in the three sampled kernel values.
The admissible cone is defined by G0 >= G2 and n dot G <= 0, with
n = (-3,4,-1). Let the true kernel be G = (1,4/5,1/5) and the estimate
be Ghat = G + h(1,1,-1), for small positive h. The second constraint is
violated by 2h. Its Euclidean projection is

\[
\widetilde G
=\widehat G-\frac{h}{13}(-3,4,-1)
=G+h\left(\frac{16}{13},\frac9{13},-\frac{12}{13}\right).
\]

This projected point also satisfies G0 >= G2, so it is the projection
onto the whole cone. Its defect is zero. Nevertheless,

\[
\|\widehat G-G\|_\infty=h,
\qquad \|\widetilde G-G\|_\infty=\frac{16}{13}h.
\]

The entrywise error used in the regret bound has increased. Conversely,
an estimate displaced directly outward along n projects back to the
true boundary point, improving the error. Therefore the correct statement
is that projection removes the tested defect **without guaranteeing an
improvement in the regret bound**. It is also wrong to claim that
projection can never improve that bound. No claim about the direction of
change in actual realized policy regret follows solely from these norm errors.

**Grid inclusion matters.** The continuous-horizon monotonicity argument
in Proposition 14.2 embeds every shorter-horizon trade into the longer
horizon. For discrete grids, the same argument requires grid inclusion.
Consider a continuous nonincreasing kernel with values (1,0.95,0.2,0)
at times (0,1,2,3), for example its piecewise-linear interpolation. The
grid {0,1,2} has defect 3/40. The grid {0,3} has defect zero: a zero-mass
trade (a,-a) has energy 2a squared. The final time increased but available
trading times changed. The revision adds the nested-grid qualification.

**Contribution and verification.** T2 contributes an explicit finite-grid
criterion, an exactly computed defect and a sharp stability example. T3
connects two existing results in the manuscript: the volume-scaling identity
already appears in Proposition 14.2, and the entrywise error estimate is
the same inequality used in Proposition 29.1. Its practical interpretation
is useful, but it should be presented as a corollary and integration of
existing results, rather than a separate foundational theorem. A complete
literature priority claim has not been established by this review.

The independent rational checker optimizes the original quadratic form
over all six TV-polygon edges and the zero trade. It checks endpoints and
interior stationary points, rather than using the proposed formula to
select a minimizer. All 405 tested kernel triples match exactly, with
178 positive and 227 zero defects, 1,252 interior edge stationary points
examined and 1,215 direct expansion identities checked. Separate exact
checks verify the attaining perturbations, the opposite-direction mandate
example, the projection counterexample and the nearest admissible repair.
The existing mathematical and accounting checks also pass.

The compiled manuscript and complete source package include the reviewed
statements, proofs, checks and revision records. Build and visual evidence
are recorded in `audit/build_verification.json`; computational evidence is
in `audit/mathematical_checks.json`. The checks support the stated formulas
and implementation, not empirical trading performance or a global grade
for the entire manuscript.
