# Final v12 (Lean-companion build)

September 14, 2026. Builds on the final v12 of `FINAL_V12_FIXES.md`. The input
source is preserved in `originals/Market_Impact_Execution_v12_final_before_lean.tex`.

## Changes applied

1. Corollary 13.2 retitled from "One asset cannot be manipulated by permanent
   impact" to "Zero loop cost in one asset" (label `cor:oneasset`), with a
   closing sentence restricting the claim to the permanent channel and pointing
   to Proposition 13.6 and Corollary 13.8 for the transient and temporary
   channels. This aligns the corollary with the abstract's hedge.
2. The cost-functional definition opening Section 12.1 no longer depends on
   the forward reference to Proposition 23.1 for its meaning; the arrival
   price is named in place, with Proposition 23.1 cited for the full
   shortfall accounting.
3. New Appendix E, "A machine-checked core", describing the Lean 4
   formalisations of Theorem 13.1 (finite-grid form, with Corollary 13.2 as
   the d = 1 case), Corollary 12.8 (ray form) and Theorem 27.1. The appendix
   is gated by a preamble switch `\ifleanverified`, shipped OFF: the text as
   built states that the formal sources are supplied and that the kernel
   check is not part of this version. It records explicitly that the trace
   pairing in the formal statement equals the −2∑_{i<j} A_ij 𝒜_ij form of
   (13.2) with no orientation change, and that the continuum statement, the
   analytic input, and the certificates of Sections 17 and 29 are not
   formalised.
4. One sentence added to the reading guide (Section 1.1) pointing to
   Appendix E; one clause added to Appendix D listing `lean/`.
5. New `lean/` directory: `lakefile.lean`, `COMPILE.md`, and
   `MarketImpactCore/{LoopCost,QuarticSign,VenueConvex,Audit}.lean`.
   Zero `sorry`, zero added axioms in the source. NOT compiled in this build
   environment (no Lean toolchain; Mathlib cache unreachable). `COMPILE.md`
   gives the four-step build and audit sequence and the exact condition under
   which the preamble switch may be flipped.
6. New `scripts/fwdref_audit.py`: forward-reference audit for the LaTeX
   source. Run as `python3 scripts/fwdref_audit.py main.tex`.

## Verification

The 108-page PDF builds with pdfTeX 1.40.25 (lmodern from the distribution)
with zero LaTeX warnings, no undefined or multiply defined labels, and no
overfull boxes. Underfull boxes are confined to the pre-existing bibliography
and table lines.

Forward-reference audit: 46 references point five or more subsection-units
ahead. All but one are either reading-guide pointers in Section 1, roadmap
pointers in Section 21, or "complements/see also" cross-references, none of
which is a proof dependency. The one definitional dependency (Section 12.1 on
Proposition 23.1) was removed in item 2. Section 17 and the opening of
Section 18 contain no forward proof dependencies.

Numerical results, figures and generated tables are byte-identical to the
preceding final v12. The Python workflow was not rerun for this textual and
artifact-only revision.

## Not done, deliberately

Corollary 13.3 is not formalised: instantiating the area pairing at the
rectangular loop is a `simp`-normal-form exercise best written against a
compiling Mathlib. The Lean sources have not been compiled; the paper's
Appendix E says so.
