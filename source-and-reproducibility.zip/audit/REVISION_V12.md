# Revision v12: a computable certificate under partial observation

Date: September 14, 2026. This revision extends v11; the supplied wording
corrections in Assumption 12.2 and Sections 32.6 and 33.5 remain in place.

## Mathematical addition

Section 29.7 states a finite-observation, binary-hidden-state execution model
whose actions affect both hidden liquidity and observations. Observable state
retains the ledger and all variables required by the feasible action mask.
The initial prior is a mesh node. Costs, primitive kernels and remaining-cost
range bounds are supplied explicitly.

Theorem 29.18 computes a lower bound on the optimum over all policies using
the declared observation history, and an upper bound on the actual cost of a
feasible finite-memory controller. Their difference bounds global regret.
The lower recursion uses concavity and interpolation. The controller updates
a recursively rounded belief and is evaluated in the physical hidden-state
model; the physical regime is never resampled from the rounded belief.

Proposition 29.19 supplies explicit mesh bounds and a computable numerical
optimization tolerance. Its comparison proof introduces artificial hidden
resampling in forward order, so each replacement has the correct conditional
posterior under the common prefix. This avoids assuming uniform stability
of Bayes' formula after rare observations.

Corollary 29.20 implements the finite controller using depth-one signature
features of an added observable summary channel, finite scores and an exact
action mask. The summary has dimension |X|(m+1); the result is not a
dimension-free depth guarantee for the raw transcript. A uniform model-cost
error B_T adds 2 B_T to the computed approximate-model regret certificate.

## Attribution and contribution

The revised comparison in Section 29.8 credits Cont, Degond and Xuan for the
order-flow and clearing foundation, and classical POMDP work for belief
dynamic programming, piecewise-linear concavity and computable planning
bounds. Smallwood and Sondik (1973), Lovejoy (1991), and Walraven and Spaan
(2019) are cited explicitly. General signature-control approximation is also
credited to the existing literature. No claim of priority is made for these
foundations.

The added construction combines observable execution feasibility, a finite
belief controller, physical policy evaluation, a computable global gap,
finite-score signature implementation and the manuscript's model-error
transfer statement. Its accuracy parameter is the belief mesh and table
size. It does not establish convex training of endogenous signature scores,
equivalence to a richer continuous-time observation filtration, or an error
bound for an unvalidated market model.

Primary references checked for this addition:

- Cont, Degond and Xuan (2025), SIAM Journal on Financial Mathematics 16(1),
  123–166: https://epubs.siam.org/doi/10.1137/22M1541538
- Smallwood and Sondik (1973), Operations Research 21(5), 1071–1088:
  https://pubsonline.informs.org/doi/10.1287/opre.21.5.1071
- Lovejoy (1991), Operations Research 39(1), 162–175:
  https://pubsonline.informs.org/doi/10.1287/opre.39.1.162
- Walraven and Spaan (2019), JAIR 65, 307–341:
  https://jair.org/index.php/jair/article/view/11324

## Reproduced benchmark

Section 33.9 uses a synthetic 1,000-share parent, twelve decisions, seven
instructions and hidden good/bad liquidity. Actions change regime transition
probabilities and fill laws. The controller sees its own actions, fills,
public binary signals and remaining quantity. The completion facility and
all USD charges are stipulated parts of this finite model.

At 1,025 belief nodes, the lower bound is 16.48417271399559 USD and the
deterministic controller's cost upper bound is 16.48417295526637 USD. The
computed global gap is at most 2.412707793553182e-7 USD. The implemented
finite-score signature policy, with preferred weight 2^20, has cost upper
bound 16.48420865721145 USD and gap at most 3.594321585964622e-5 USD.

The deterministic policy improves expected cost by approximately 6.36%
relative to the specified frozen-prior policy and 7.90% relative to the
specified action-independent-transition policy. Both baselines are evaluated
under the same physical controlled model. The six tested prior/deadline
combinations improve on both baselines. These policies are explicitly
defined comparators, not optima over every possible policy omitting the
corresponding information. The fully observed regime oracle is reported
separately and is not used as the partially observed optimum.

The eight mesh cases show why an actual certificate matters: the deployed
policy does not improve monotonically at every refinement. The mesh's
uniform bound is conservative; the computed lower/upper gap supplies the
useful stopping criterion. These are planning-accuracy results inside an
exact synthetic model, not precision claims about market execution costs.

## Verification

The full numerical workflow completed successfully in v12. The final new
script was rerun after adding the online observable controller interface.
The 23 pre-existing figure, result and generated table assets reproduce
byte-identically to v11.

- Independent exact-rational exhaustive history optimization for three
  decisions and two units visits 3,553 distinct states and gives
  232172138011/156250000000 = 1.4859016832704 USD. This value lies between
  the computed lower and upper bounds.
- Independent exact-rational evaluations of deterministic and finite-score
  controllers lie inside their outward numerical intervals.
- All 24,600 integer posterior-rounding and probability-enclosure cases pass.
- Independent forward physical occupancy agrees with backward evaluation
  within 1e-10 USD, with maximum probability-mass error 2.22e-16 and 9,390
  positive-probability stage/memory states.
- All 240 signature, action-mask and memory checks pass. The online
  BeliefSignatureController has no hidden-regime input. Its first-level
  summary signature produces the table scores, and its integer sampler
  implements the rational finite-score softmax law.
- Certificate arithmetic expands elementary binary64 operations outward
  using adjacent floating-point numbers. The implementation uses exact
  integer likelihoods and quantization. These numerical enclosures and
  checks are not a machine-verified formal proof of the general theorem.

The 106-page PDF compiles with no unresolved references or citations,
duplicate labels, or overfull boxes. There are 337 distinct source labels,
82 bibliography entries and eleven figures. All pages were rendered and
reviewed in contact sheets. The cover, contents, new theorem/proof pages,
new experimental pages and the following Part VIII opening were also
reviewed at higher resolution. No clipped text, missing figures or
overlapping elements were observed. All nine part-page references match
their actual title pages. Nine underfull-box notices remain from existing
material; they do not create visible overflow.

## Deliverables and limits

The package includes the compiled PDF, complete LaTeX inputs, scripts,
policy arrays, generated figures/tables, machine-readable check results,
current build/provenance records and a SHA-256 manifest. Earlier source and
audit records are retained as historical material. The manifest verifies
file consistency and is not an authenticity signature.

This revision strengthens the constructive result and its reproducibility.
It does not establish a publication grade or replace independent review.
No external submission or publication was performed.
