# Final v12: supplied snippet integration

September 14, 2026. This is the final v12 requested by the author. It integrates
all five changes in `originals/fix_snippets_v11.tex` into the preceding v12,
while retaining the partial-observation certificate and its numerical results.
The input source is preserved in
`originals/Market_Impact_Execution_v12_before_fixes.tex`.

## Changes applied

1. Replaced the abstract with the thesis-first, ranked-results version.
   The loop claim is explicitly about linear permanent impact in the stated
   frictionless model. The exact quadratic signature objective explicitly
   assumes an exogenous feature path.
2. Added Section 1.1, the reading guide, immediately after the first
   introductory paragraph. Existing introductory discussion follows as
   Section 1.2. All proposed references were mapped to actual document labels;
   the constructive partial-observation result remains visible in the guide.
3. Added Proposition 12.10 and its proof for the energy-based analytic
   crossover. The energy is explicitly bounded, nonnegative and sensitive to
   schedule shape. The positive-energy hypothesis is stated for the
   three-halves asymptotic. The minimizer-set identity does not assume
   existence on L2. The remark explains why endpoint-atom optimizers require
   the separately defined measure domain, retains the minimal size-only
   example and preserves the exact 16/9 level/slope matching calculation.
4. Replaced the opening of Section 18 with a self-contained statement of the
   information-value question and subsequent applications.
5. Added Section 36.4 on the temporal-skew and joint size-tail restrictions.
   It distinguishes strategic trader counts from print counts and identified
   metaorders from individual trades. The exponent pair yields one scalar
   equality; observing the permanent fraction supplies a second. Finite-size
   comparisons retain the cutoff term. These are proposed conditional tests,
   not empirical tests already performed or identified from public prints
   alone.

The evidence table, estimation remark and scale-invariance outlook item now
have stable labels. The reproduction appendix correctly reports eleven
figures. Contents spacing avoids an isolated final entry, and an explicit
page break makes the Outlook contents entry agree with its title page.

## Verification

The new `scripts/analytic_crossover_checks.py` passes three independent
energy-versus-ODE comparisons, eighteen independent constrained optimizations
of the transformed objective against known finite-grid energy minimizers,
and six small-/large-size regime checks. Its result is recorded in
`audit/analytic_crossover_checks.json`, and it is part of the complete
reproduction entry point.

The existing mathematical and accounting checks were rerun and passed.
All figures, generated tables and stored experimental results from the
preceding v12 remain byte-identical. The full pre-existing numerical workflow
was verified in that preceding build; it was not unnecessarily rerun for
this primarily textual revision.

The final 107-page PDF builds without undefined references or citations,
duplicate labels, or overfull boxes. The final build and provenance records
contain the source hashes, resolved reference checks and visual-review scope.
The supplied snippet is preserved unchanged, so the mathematical
qualifications made during integration remain reviewable. Numerical checks
corroborate the new construction; the manuscript contains its proof.

`audit/REVISION_V12.md` describes the original partial-observation addition.
The corresponding original build records are retained as
`audit/build_verification_v12_before_fixes.json` and
`audit/provenance_v12_before_fixes.json`. Current authoritative build records
are `audit/build_verification.json` and `audit/provenance.json`.
