# Reviewed corrections to the market microstructure trilogy

The supplied DOI, notation and proof-clarification fragments have been applied
to the existing manuscripts. Equation and theorem labels are preserved.

## Paper 1: execution

- The title-page DOI and PDF subject now use 10.5281/zenodo.22736805.
- The finite belief-grid action values and numerical excesses use tildes,
  separating them from the richer-history action bounds in Section 29.8.
- Alternative actions use a prime; binary posterior intervals use script I.
- The feasible-action count is indexed by stage and summary, so it does not
  conflict with the belief-mesh parameter.
- The reading guide now links directly to Section 29.4. The Section 29
  overview names the two computable certificate subsections.
- Assumption 29.21 explicitly names conditional action-law envelopes.
- Section 33.10 prints the exact information-loss fraction and decimal.
- The liquidity-learning research item identifies validated posterior
  envelopes from reports and timestamps as the remaining construction task.

## Papers 2 and 3

Both execution-paper bibliography entries retain their existing citation key
and now carry the new DOI in both the DOI and URL fields.
Paper 2 makes the KL-to-total-variation Pinsker chain explicit.
Paper 3 defines the Gaussian upper tail and names the Mills-ratio expansion;
the existing equation label eq:gaussian is retained. The preceding formulas
already used the correct upper tail and Pinsker constant.

## Verification

The existing exact finite-tree script was rerun. Both mesh sizes 8 and 16
with report probabilities 0.05/0.95 give:

- Rich-history optimum: 3529592805260631/2500000000000000.
- Coarse-history optimum: 729580613/488281250.
- Information loss: 205859933299369/2500000000000000,
  exactly 0.0823439733197476 USD.

The run passes 1,047 conditional cost comparisons, 3,711 state-action
comparisons and 1,474 strict screening comparisons across its three cases.
The existing Gaussian-value and smooth-threshold check was also rerun and
passed. Its Gaussian formula agrees with direct numerical integration.

The prior 41-group verification suite for Papers 2 and 3 remains included;
the numerical models and verification implementation are unchanged in this
correction pass. The focused results are in reviewed_fragment_checks.json.
The Lean sources are unchanged and were not rebuilt for these textual edits.

All three date commands remain set to LaTeX today. No deposit date is inferred
from a manuscript build, and no external deposit or metadata record is changed.

## Final build and layout

The corrected PDFs contain 117, 37 and 35 pages. All three compile without
unresolved references or overfull boxes. Every page was rendered; changed
content pages and the affected mathematical displays were visually checked.
Paper 1 retains the nine underfull-box notices present in its preceding build.
