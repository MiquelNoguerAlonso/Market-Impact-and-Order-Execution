# Integration of aplus_snippets_v8.tex

The supplied file proposes one coefficient correction and two additions to
the 79-page integrated manuscript. Its contents are retained unchanged in
`originals/aplus_snippets_v8.tex`. The revised manuscript has 81 pages.

| Item | Finding | Integrated result |
| --- | --- | --- |
| T1: Example 14.4 | The claimed inversion is not present in the actual source: `\tfrac25` means 2/5 and `\tfrac3{10}` means 3/10. The previously reported energy, defect and profit are correct. | Makes both fractions explicit with braces, introduces p = u + v and d = u - v, and labels the equation. This is a clarity edit, not a numerical correction. |
| T2: Three-point formula | Correct under G0 >= G2 and the fixed-grid, full total-variation normalization. | Adds Proposition 14.5, its proof, and Remark 14.6. Gives the exact threshold 4 G1 <= 3 G0 + G2, distinguishes discrete convexity from round-trip admissibility, and gives an explicit witness proving Lipschitz constant 1 is sharp. |
| T3: Phantom profit | The scaling identity and estimation-error bound are correct for the impact component and the stated signed round-trip comparison set. | Adds Corollary 29.2 and Remark 29.3 after Proposition 29.1, with the zero-volume case, an entrywise matrix proof, and a cross-reference from Section 21, item 2. |

## Qualifications incorporated into the manuscript

- The three-point defect is the **positive part** of a linear contrast. It is
  piecewise linear, not a linear functional on the whole stated kernel domain.
- A three-point admissibility calculation does not establish admissibility
  for an interpolated continuum kernel or for additional trading times.
  Grid monotonicity is explicitly restricted to nested grids under a common kernel.
- A zero-defect kernel can still have a signed mandate optimum that trades
  in both directions. The integrated Remark 14.6 proves this using
  (1, 0.7, 0.2), whose signed unit-buy cost is 11/40 compared with the
  buy-only optimum 3/10.
- The Lipschitz claim is made exact: for G = (1, 0.95, 0.2) and
  H = G + h(-1, 1, -1), 0 < h < 1/40, both the uniform distance and defect
  increase equal h. Both sampled kernels remain nonnegative and nonincreasing.
- Phantom profit is measured in the impact component. Its comparison set
  permits all signed round trips under a gross-volume cap. Additional policy
  constraints may lower the attainable value; a buy-only class has only the
  zero round trip. Spreads, fees and other execution charges are separate.
- Projection onto the fixed-grid admissible cone eliminates the defect on
  that grid. It does not, without an additional error comparison, establish
  that the matrix's entrywise distance to the true model or the regret bound
  improves. The revised text avoids asserting that projection can never help.
- Placeholder references have been replaced by the manuscript's actual
  labels. A labeled Lipschitz equation is added to Proposition 14.2.

## Verification

`scripts/defect_checks.py` supplies an independent exact-rational minimizer
of the original quadratic form over the six edges of the TV-unit polygon.
It checks endpoints and every feasible interior edge stationary point. A
negative homogeneous quadratic achieves its minimum on the boundary; the
zero trade handles the nonnegative case. This calculation does not use the
p,d reduction or the proposed defect formula to locate the minimum.

- All **405** tested kernel triples satisfying G0 >= G2 match the formula
  exactly: 178 have positive defect and 227 have zero defect.
- The checks cover **1,252** interior edge stationary points and **1,215**
  exact comparisons of the direct matrix energy with the p,d expansion.
- The example coefficients are 2/5 and -3/10. The normalized defect is
  3/40, the unnormalized loop energy is -6/5, and volume-four profit is 3/5.
- The convex, nonconvex-admissible, boundary and positive-defect examples
  all match. A separate kernel (0, 0, 1) shows why dropping G0 >= G2 would
  invalidate the displayed formula.
- An admissible true kernel (1, 4/5, 1/5) and the estimate
  (99/100, 81/100, 19/100) attain the phantom-profit bound for gross volumes
  0, 1, 4 and 10. The entrywise error and estimated defect are both 1/100.
- `python3 scripts/verify.py` and `python3 scripts/audit_checks.py` passed.
  The full reproduction entry point incorporates the new checks through
  `verify.py`; unchanged simulations were not rerun for these analytic edits.
- The expanded exact checks verify the opposite-direction mandate optima
  through their potentials, and a sampled-value Euclidean projection that
  removes the defect while increasing uniform error by a factor 16/13.

`audit/DEEP_REVIEW_V8.md` gives the detailed mathematical review, including
the projection counterexample, the nested-grid qualification and an exact
uniform-distance consequence derived during the review.

The proofs establish the general results under their assumptions. These
exact calculations corroborate the formulas, constants and implementation;
they are not evidence of live-market performance or a novelty assessment.

Build diagnostics and visual review are recorded in
`audit/build_verification.json`. No external publication was performed.
