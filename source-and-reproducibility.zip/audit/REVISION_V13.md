# v13: stronger observation and execution theory

This revision starts from the final v12 reviewed on September 14, 2026. It adds written proofs and reproducible finite examples addressing the gap between a controller's finite observations and a richer observation history. The new results are conditional mathematical certificates. They are not a claim that realistic reporting models or posterior-error bounds have already been identified from market data.

## The new theorem chain

Section 29.8, `sections/observation_summary_certificate.tex`, contains:

| Result | Statement and proof obligation |
| --- | --- |
| Assumption 29.21 | Conditional expected-cost/next-summary-law envelopes cover every admissible full history and counterfactual feasible action; the summary preserves the exact action mask. |
| Theorem 29.22 | Lower envelope recursion bounds the full-history optimum; the selected summary policy is feasible and its cost is bounded by the upper recursion. An independently certified physical evaluation can sharpen the upper endpoint. |
| Corollary 29.23 | Singleton conditional envelopes imply exact value sufficiency. A uniform model discrepancy adds twice that discrepancy to the approximate-model certificate. |
| Proposition 29.24 | Conditional cost and total-variation prediction bounds yield an explicit regret bound using nominal continuation-value spans; the finite envelope optimizations are linear programs. |
| Proposition 29.25 | A verified interval of full posteriors in each binary-liquidity summary fiber gives a valid paired envelope. Its extrema require only the two posterior endpoints. |

The lower-bound proof applies to every full-history continuation, not just a summary policy. The upper-bound proof uses the actual conditional law and the tower property. Neither assumes that the summary is Markov. A physical fixed parameter need not be reselected at each step: the rectangular Bellman construction is a bounding relaxation, and incompatible stagewise extrema can make it conservative.

The binary construction keeps the controller's rounded memory fixed while mixing physical outcome probabilities with the full posterior. This separates deployment from hidden-state resampling. Charge and next-state errors remain paired through the same posterior. Exact enumeration of a finite history tree supplies the interval witnesses in the example; that enumeration may be exponential. The subsequent endpoint recursion has the stated finite arithmetic complexity. No general efficient interval-construction algorithm for continuous reports is claimed.

## Exact examples and checks

Section 33.10 and `scripts/observation_summary_checks.py` add three controlled-liquidity cases. Each has three decisions, two quantity units, the seven previously supplied instructions, and initial bad-state probability one half. The summary controller discards the public signal and filters fills only. The richer optimum uses fills and signals; the coarse-history optimum retains the entire fill history and therefore has no rounding error.

The script independently constructs exact rational kernels from the stated primitive parameters. It enumerates all feasible fine-report histories, merging only equal stage/quantity/memory/posterior states, and forms posterior-fiber extrema. Each case has 1, 24, 324 and 3,456 states at successive stages. The conditional sandwich is checked at every one of the 349 nonterminal states per case, for 1,047 checks. A separate forward occupancy calculation over the actual hidden state exactly matches the policy's history-based evaluation and conserves probability.

At the original 0.35/0.65 report probabilities, the richer optimum remains exactly `232172138011/156250000000`. Discarding the signal raises the optimum by exactly `1293658149/156250000000`, or 0.0082794121536 USD. With 0.05/0.95 report probabilities, that information loss is approximately 0.082344 USD. All exact costs, achieved gaps, envelope bounds and state counts are in `results/observation_summary_checks.json`; the manuscript table is generated directly from those values with outward display rounding.

A separate probe example has richer value 0.70 USD and coarse value 1.00 USD. The information loss remains 0.30 USD with an exact coarse filter and zero quantization. Its envelope certificate is 0.62 USD. Retaining the report gives singleton envelopes and exact equality of lower and upper values at 0.70 USD. These fractions are checked directly.

The script also checks a nonuniform grid containing prior 1/3 and Gaussian sign symmetry. These finite arithmetic checks support the written proofs; they do not formally verify the general theorem.

## Corrections and contribution framing

The Gaussian saving in Theorem 18.2 now uses the absolute mean shift. Its proof states the reversed decision inequality for a negative shift and the uninformative zero case.

The belief grid in Section 29.7 is the union of the uniform grid and the initial prior. Its largest cell remains at most 1/m. The interpolation proof uses the actual adjacent-cell length, and controller dimensions use the grid's actual cardinality, at most m+2. Analytic real-data statements are separated from algorithmic claims requiring rational data or validated enclosures and certified memory-update comparisons. The existing synthetic grids already contain all tested priors, so their numerical assets are unchanged.

The compound surname Abi Jaber is corrected in both the author-year label and author text, and the reference is placed alphabetically.

The abstract, reading guide, conclusion and Section 29.9 foreground the execution-certificate construction. The comparison explicitly credits Cont–Degond–Xuan for order-flow/clearing, Cont–Kukanov for queue-aware venue placement, Kalsi–Lyons–Perez Arribas and Bank et al. for signature-control foundations, classical POMDP work for belief planning, and Iyengar and Nilim–El Ghaoui for robust dynamic programming. The depth-one one-hot construction is identified as a growing table encoding; it does not demonstrate signature compression or improved sample complexity.

## Verification and retained scope

The complete ten-script numerical reproduction workflow passed. All 32 pre-existing numerical figure, table and result files reproduced byte for byte. The new exact rational checks and generated table also passed. Build and output hashes are recorded in the current provenance and manifest.

The 114-page PDF compiles with no unresolved references or citations, duplicate labels, or overfull boxes. The table of contents fits on three pages. All pages were rendered and inspected in contact sheets, with detailed checks of the new theory, examples, corrected formula and contribution text. Existing underfull-box notices are layout advisories, predominantly in the bibliography.

The seven Lean source/configuration hashes match the prior successful kernel-check record. Those unchanged Lean files were not rebuilt for v13. Their scope remains the finite-grid loop identity, scalar ray argument, feasible-domain convexity and consistency lemmas specified in Appendix E. The new observation-summary theorems are not formalized in Lean.

No external submission, DOI-record change, publication or repository push was performed. The existing attribution, DOI, author-year citation style, date convention and manuscript structure are retained.

## Primary sources checked for the robust-DP attribution

- Garud N. Iyengar, “Robust Dynamic Programming,” *Mathematics of Operations Research* 30(2), 257–280 (2005), [publisher record](https://pubsonline.informs.org/doi/10.1287/moor.1040.0129).
- Arnab Nilim and Laurent El Ghaoui, “Robust Control of Markov Decision Processes with Uncertain Transition Matrices,” *Operations Research* 53(5), 780–798 (2005), [publisher record](https://pubsonline.informs.org/doi/10.1287/opre.1050.0216).

The other foundation comparisons and the baseline review are recorded in `audit/DEEP_REVIEW_V12.md`, which concerns the preserved v12 source rather than this revised manuscript.
