# Final review of the original market-impact and execution paper

Miquel Noguer Alonso — Artificial Intelligence Finance Institute (AIFI)  
Edition v14, 14 September 2026

This edition completes the original manuscript. The separate order-book
prediction draft, models, data, figures and bibliography additions are
excluded. The original paper's NYSE/Nasdaq, impact, allocation, information,
control and execution-certificate material is retained.

## Final theoretical refinement

Theorem 29.26 uses the conditional envelopes already introduced in Section
29.8. It converts lower/upper action values into bounds on true Bellman
advantages and propagates them for a feasible summary controller. The result
applies to deterministic and behavioral randomized controllers and compares
them with the richer-history optimum.

Its practical distinction is between uncertainty about a cost and uncertainty
about the best instruction. If an instruction's upper action value is below
the lower values of all alternatives, it is optimal throughout that summary
fiber. The certificate can therefore be zero even when the conditional
optimal cost varies within the fiber and the original cost interval has
positive width.

The paper also states a strict screening criterion. An action whose lower
bound exceeds another action's upper bound cannot be optimal in any history
covered by the fiber. Ties are preserved. Screening never changes the
underlying reservation, status or completion constraints.

Both certificates remain available. The reported final bound takes the
minimum of the physically evaluated cost certificate and the action
certificate. Neither is claimed to be uniformly sharper. Approximate-model
transfer retains the existing addition of twice the fixed-policy model
discrepancy.

These are refinements of established Bellman bounding ideas within the
paper's declared execution and information setting. The attribution to
order-flow/clearing, queue-aware venue placement, signatures, POMDP planning
and robust dynamic programming remains explicit; no general priority claim
over those foundations was added.

## Proof review

The final pass examined the following links in the central argument:

| Link | Required condition and review conclusion |
| --- | --- |
| Exact signature objective | The feature law is exogenous; exponential augmentation supplies the stated finite degrees. Endogenous fills do not inherit that quadratic identity. |
| Pathwise completion | The derivative construction integrates to zero path by path; the common compact coefficient set preserves the stipulated rate limits. |
| Kernel/moment certificate | Both objectives use the same feasible set; the constant coefficient cancels, and each policy comparison charges the stated error terms. |
| Controlled-book transfer | Joint paths include own fills, costs and reports; bounded loss and common feasible history policies remain explicit. |
| General signature class gap | Complete observable transcripts, exact masks, finite actions and the hybrid-policy laws are retained. The result is existential and supplies no generic depth rate or global optimizer. |
| Computable partial observation | Concavity gives the lower relaxation; physical hidden-state evaluation gives the upper endpoint. Recursive memory rounding is distinguished from a true posterior and from resampling in the comparison proof. |
| Richer-history certificate | Conditional envelopes cover every feasible history and counterfactual action. The lower proof permits richer continuations, and the upper proof evaluates a feasible summary policy. |
| Action-comparison refinement | The true Bellman action value lies between its envelope bounds. Excluding the selected action from the alternative minimum gives a valid nonnegative advantage bound; the one-action case is exactly zero. Backward induction propagates continuation regret. |

The new recursion does not charge immediate cost a second time. It propagates
the next-summary law only after accounting for the action advantage. A
randomized controller averages actionwise bounds according to its implemented
probabilities. Binary posterior envelopes preserve the dependence of cost and
transition through the same posterior, and endpoint evaluation remains valid
for each fixed continuation vector.

No unresolved defect was found in these examined arguments. The review is
not a formal verification of the complete monograph. The central remaining
conditions are mathematical assumptions stated in the paper, including
bounded losses, adequate observable masks, and validated conditional
envelopes. A fitted model alone does not establish those envelopes.

## Exact and numerical verification

The complete ten-script reproduction command passed:

~~~sh
python3 scripts/reproduce.py
~~~

The exact observation-summary script now checks:

- 1,047 nonterminal conditional cost sandwiches across three finite trees;
- 3,711 feasible full-posterior/memory state–action comparisons, including
  action-value enclosures and Bellman-advantage bounds;
- 1,474 strict screening comparisons, each checked against exact true
  action values;
- action-regret bounds for the selected policy at all 1,047 nonterminal states;
- independent forward physical hidden-state evaluation and conservation of
  probability;
- a non-singleton example with deterministic optimal cost 0.17 USD, a
  0.05 USD cost certificate and an exactly zero action certificate;
- a randomized version with actual regret 0.0875 USD and action bound
  0.10 USD, including separate checks in each hidden state.

All three original controlled-liquidity examples favor the original cost
certificate over the action certificate. The new table reports that result.
The non-singleton example demonstrates the opposite ordering. These are
synthetic finite constructions, with exact fractions retained in the results.

All 33 other pre-existing files in results/, tables/ and figures/ reproduced
byte for byte relative to v13. The observation-summary result gains the new
check fields without changing its preceding values, and one generated table
is added. The original eleven figures are unchanged.

The supplied wording fixes remain: truncation consistency in Assumption
12.2, the explicit Table 12 Monte Carlo standard error in Section 33.5,
and the excess-demand/excess-supply interpretation in Section 32.6.
The Gaussian absolute-value correction, general initial-prior grid and
compound surname Abi Jaber are retained.

## Build and presentation

The final PDF has 116 pages, 84 bibliography entries and eleven figures.
The source contains 375 unique labels. The build has no unresolved references
or citations, duplicate labels or overfull boxes. Nine underfull-box
advisories remain, mainly in bibliographic and table paragraphs.

All pages were rendered for visual inspection, with detailed checks of the
new theorem, proof, action-comparison table and example. The contents remain
on pages 2–4. The Lean-scope explanation was shortened without changing its
meaning to remove a nearly empty overflow page before the bibliography.

Current build, source and output hashes are recorded in
build_verification.json, provenance.json and the package manifest.
Earlier reviews and verification records retain their edition names.

## Formal companion and scope

All seven Lean source/configuration hashes match the prior successful
Lean 4.19.0 / Mathlib v4.19.0 kernel-build record. The unchanged formal
sources were not rebuilt in v14. Their declaration and axiom scope is
documented in lean/COMPILE.md and audit/lean_verification.json.
The action-comparison theorem and the general execution certificates are
written proofs, not Lean formalizations.

The manuscript is a theoretical monograph with reproducible finite examples.
It does not establish signature compression, a sample-efficiency advantage,
market calibration or live-market outperformance. No submission, publication
or DOI-record update was performed.
