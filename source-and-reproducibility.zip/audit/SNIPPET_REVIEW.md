# Integration of aplus_snippets.tex

The six supplied snippets were checked against the actual 77-page manuscript
and then integrated with the corrections below. The supplied file is preserved
unchanged in originals/aplus_snippets.tex; main.tex contains the reviewed
statements and the references appropriate to this manuscript.

| Snippet | Finding | Implemented change |
| --- | --- | --- |
| S1: crossover | The existing equation already correctly states square root of X equals the coefficient ratio. The claimed algebraic error was not present. | Displays the two solved sizes explicitly and gives their ratio, 16/9. Exact rational checks verify both matching equations. |
| S2: transient energy and area | The central identity and reversal argument are correct, but the stated corollary and limitation are too strong. | Adds the decomposition with explicit rate-space, benchmark, and reversal assumptions; corrects the scalar and permanent limits; proves a short-loop necessity result and an endpoint-aware exponential lift; extends the decomposition to lag-dependent matrix kernels. |
| S3: partial translations | The finite-horizon qualification is useful. An off-diagonal simplex alone loses distributional terms supported on coincident times. | Revises both theorem and proof and gives the full increment domain, including diagonal-supported distributions, in a separate remark. |
| S4: defect scope | The factor of one half was already in the profit formula, and the Riesz paragraph already followed the proof. | Makes the energy-to-cost reference explicit, checks the gross-volume-four example, and gives the singular-kernel qualification its own remark. |
| S5: finite-sample count | Correct sharpening. The symmetric matrix has J(J+1)/2 distinct entries. | Uses J(J+3) inside the two-sided union-bound logarithm, cites both prerequisite theorems, and updates the experimental confidence bounds. |
| S6: expected signatures | The existing proof already gives polynomial coordinates and the two explicit laws. | Adds the explicit passage from matching scalar moments to matching the entire expected signature, and checks quantity and temporary cost exactly. |

## Corrections to S2

The cost is measured relative to the initial-price benchmark. The integration
domain is deterministic L2 rates with an L1 scalar kernel, or an integrable
matrix kernel; these assumptions ensure absolute convergence. The
nonnegativity equivalence applies to a class closed under reversal. Adaptedness
alone does not ensure that reversing a stochastic strategy is admissible.

The scalar reduction requires a positive impact multiplier. If the symmetric
energy vanishes, the conclusion is that the weighted-area pairing vanishes
on the tested class. Inferring that the matrix A itself vanishes requires
enough admissible weighted areas to identify all its entries. For a concrete
counterexample, take g(r)=r, S=0, and any nonzero antisymmetric A. The cost is

    (integral t v_t dt)' A (integral v_t dt),

so every zero-net-trade path costs zero. The revised corollary states the
necessary nondegeneracy instead of asserting A=0 without it. A separate result
shows that continuous g with g(0)>0 and arbitrarily short rectangular loops
does force A=0 in the impact-only model.

The proposed claim that a lag-dependent matrix kernel cannot be split was
incorrect. Decompose its value at each lag into symmetric and antisymmetric
parts. Time reversal preserves the lag, keeps the symmetric energy fixed,
and reverses the antisymmetric pairing. The revised manuscript gives this
formula and connects it to the established matrix-kernel energy framework.
See [Alfonsi, Klöck, and Schied (2016)](https://pubsonline.informs.org/doi/10.1287/moor.2015.0761),
especially the energy representation in Lemma 2.3 of the
[author manuscript](https://arxiv.org/pdf/1310.4471).

For a finite exponential mixture, the impact-state equation also gives the
lift directly. Its symmetric contribution contains both a terminal quadratic
term and a dissipation integral; its antisymmetric contribution is the area
of the actual, possibly open impact path. No closed-lift assumption is needed.
The paper states this finite-mixture result and does not assert unrestricted
motion in the lifted state space or an automatic infinite-mixture extension.

## Verification

- Twelve model/path pairs cover permanent impact, a scalar exponential, a
  scalar mixture, and a lag-dependent matrix kernel, each on two closed paths
  and one open path. Exact cell integrals and independent ODE integration
  agree to a maximum discrepancy of 1.03e-13.
- Each pair also checks reversed cost, symmetric-energy invariance,
  weighted-area sign reversal, and the endpoint-plus-dissipation formula.
- A closed unit-square inventory path ends with a nonzero exponential
  impact state, approximately (-0.27113205, -0.34814044). The retained
  endpoint term is positive and necessary for the identity.
- Short-loop costs at horizons 0.1, 0.01, and 0.001 are approximately
  -1.92954314, -1.99292023, and -1.99929170, approaching the permanent
  signed-area cost -2. Each satisfies the stated continuity error bound.
- The g(r)=r counterexample is checked on both closed paths and the open
  path, including the exact first-moment/net-quantity factorization.
- For J=3, the concentration calculation counts nine distinct coefficients,
  giving 18 rather than 24 in the two-sided logarithm. At confidence 95%,
  the coefficient bounds shrink by about 2.36%. All nine certificate
  experiments still satisfy the deterministic and finite-sample checks.
- Thirty-one expected ordinary signature coordinates through depth four
  match exactly in rational arithmetic. Both laws have expected quantity
  3/20 and temporary cost 1/15, while transient expected costs differ.

The changed calculations were rerun with scripts/verify.py,
scripts/certificate_experiment.py, and scripts/audit_checks.py.
The six-policy simulation was unchanged and retains its previously
reproduced results. scripts/reproduce.py includes the new checks through
its existing verification entry point.
