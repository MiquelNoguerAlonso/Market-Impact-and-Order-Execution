# Order flow, clearing, impact and execution: integration review

This record covers the September 14, 2026 bridge added to the manuscript.
It reviews the new construction, proofs, cross-references and numerical
implementation. It is not a fresh proof-by-proof audit of the entire paper.
The earlier v8 review is preserved as a historical record.

## What the bridge establishes

1. **A constructive matching and ledger layer.** Ordered queues retain owner,
   price, priority and residual size. The continuous price-time routine
   produces a cleared book and a trade/report list. A proposition proves
   book conservation and the parent reservation invariant. Pending exposure
   is released only on an authoritative report.
2. **A controlled transition law.** Bounded primitive mark intensities and
   deterministic matching maps construct a nonexplosive finite-state process
   by uniformization. The generator, additive event-cost expression, marked
   interval kernel and general joint Bayesian update are explicit. The
   reduction to aggregate depth is tested by a same-depth/different-fill
   queue counterexample.
3. **A conditional impact reduction.** For a stationary environmental book,
   an affine generator intervention gives
   `G_book(t) = pi B exp(t L_0) m_0`. The variation-of-constants proof gives
   an explicit second-order remainder. A two-state price model yields an
   exact exponential response. This does not identify the user's empirical
   impact kernel or imply that every book has positive exponential modes.
4. **A primitive-rate path certificate.** With the same initial full-state
   law and event/decision maps, the effective mismatch rate is
   `d = 0.5 sup_(s,a) [sum_e |nu - nu_hat| + |lambda - lambda_hat|]`.
   Coupling the same Poisson clock gives full-path TV at most
   `1 - exp(-d T)`, uniformly over common history policies. Initial-law,
   event-map and numerical tail errors are identified separately.
5. **The impact/control interface.** A same-path cost error `D_cost` and a
   total approximate loss range of width `L` give fixed-policy error
   `D_cost + L [1 - exp(-d T)]`. Twice this error, optimization tolerance and
   the true policy-class gap bound regret. On the declared single-asset grid,
   `D_cost = Q^2 epsilon_K / 2` for impact-only coefficient error. The range
   `L` includes variation in impact cost across different fill trajectories.

## Attribution and scope

The primitive-flow/clearing decomposition and its generator factorization
are credited to Rama Cont, Pierre Degond and Lifan Xuan, *A Mathematical
Framework for Modeling Order Book Dynamics*, SIAM Journal on Financial
Mathematics 16(1), 123-166 (2025), DOI 10.1137/22M1541538. The supplied
SSRN preprint was read locally; the journal metadata were checked against
the publisher and author publication records:

- https://epubs.siam.org/doi/abs/10.1137/22M1541538
- https://profiles.imperial.ac.uk/p.degond/publications
- https://arxiv.org/abs/2302.01169

The manuscript extends this interface for its own execution analysis and
provides the proofs it uses. It does not claim priority for uniformization,
Markov reward processes, linear response, filtering or the generic
two-model regret comparison. It does not reproduce the comparator's full
centered-book development or establish a stochastic scaling limit.

The ownership and priority augmentation is essential: an anonymous clearing
map does not determine the trader's cash charges, private fills or messages.
An event can leave structural state unchanged while still carrying a report
or a fee; such an event remains in the marked model. Primitive event type
proportions alone are insufficient when total event rates differ.

The partial-observation coupling freezes the same history-to-action policy
in both environments, including its learned filter and fallback behavior.
It does not assume uniformly close posteriors under the two different
models after arbitrary rare observations. This distinction avoids silently
using the stronger conditional hypothesis from the existing simulation
lemma.

Physical price/fill changes and cost-coefficient error are separate. Small
numeric price differences need not be small in total variation. Recorded
book execution prices already include modeled mechanical depletion; adding
the same effect again as propagator cost would double count it.

The earlier signature quadratic objective still requires an exogenous
signal law independent of its execution coefficients. Signature features
can parameterize feedback policies in the controlled book, but this alone
does not give a fixed quadratic moment objective. The new policy certificate
keeps any policy-class approximation gap explicit.

## Numerical implementation and evidence

`scripts/orderbook_bridge.py` supplies a 19-state FIFO book with a one-share
parent, four decisions over one second and six primitive mark types. The
synthetic book has bid/ask prices 100/101, at most two external bid units and
one ask unit, and a stipulated terminal facility at 102. This bounded
facility guarantees completion; it is not manufactured local book depth.
Cancellation at a decision is atomic. The example is fully observed and
does not implement NYSE parity, reserve, asynchronous acknowledgments or
an estimated hidden-liquidity posterior.

At true sell-arrival rate 1.2, the optimum crosses immediately and costs 1.
At estimated rate 1.4, the selected policy posts first. Its estimated value
is 0.9980425949753224; evaluated unchanged at the true rate, its value is
1.0258970846329492. Regret is 0.0258970846329492. The primitive-rate bound is
0.7250769876880724; its conservatism is stated in the paper. With sufficiently
large parameter errors the certificate is no better than the bounded loss
range. The numerical illustration varies event rates only, with no extra
impact-cost error.

The targeted checks passed:

- 3,888 variable-size matching cases verify share conservation, noncrossing
  output and best-price execution. A separate partial-fill case verifies
  FIFO priority at a common price.
- All raw mark and admissible action transitions stay in the 19-state space.
  The equal-depth queues `(O,E)` and `(E,O)` produce different private fills.
- The state matrix exponential and the Poisson expansion agree within
  7.8e-16 maximum row TV for the recorded test, subject to floating-point
  rounding. The omitted Poisson tail is 6.35e-16 or smaller; the code allows
  1e-13 rounding tolerance in the comparison.
- The exact maximum state-endpoint TV for rates 1.2 and 1.4 over 0.25 seconds
  is 0.03613013096300455, below 0.04877057549928595. The joint one-clock
  state/report pushforward also passes its TV contraction check.
- Seven estimated rates, all 19 states and all four remaining decision
  times give 532 fixed-policy/regret comparisons. All satisfy the bounds.
- The stationary response is checked against matrix exponentials for both
  constant and piecewise signed inputs. The two-state exact exponential
  formula agrees to better than 5e-16 in the tested cases.
- Independent event-time simulation uses 40,000 paths in each environment,
  drawing waiting times and raw marks without the matrix exponential. At
  the estimated rate its mean is 0.994425 (SE 0.0021177724); in the true
  environment it is 1.025125 (SE 0.0019767248). Deviations from the respective
  exact model values are 1.7083 and 0.3906 standard errors or less. These are
  Monte Carlo diagnostics, not deterministic proof certificates.
- `python3 scripts/verify.py` and `python3 scripts/audit_checks.py` passed.
  The unchanged earlier numerical illustrations were retained, with their
  original values checked by file hashes. They were not rerun for this edit.

The generator, proof checks, complete parameters, state ordering, learned
policy, numerical table, figure and simulation diagnostics are included in
the package. `scripts/reproduce.py` invokes the new example along with the
existing numerical workflow. The final build and visual checks are recorded
in `audit/build_verification.json`.

The result is a mathematical connection with a reproducible implementation
under stated assumptions. Empirical intensity estimation, uniform coverage
of states reached by new policies, production exchange validation and
infinite-state limits remain separate work.
