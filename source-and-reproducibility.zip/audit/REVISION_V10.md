# Revision v10: controlled feedback and reference-model certificates

Revision date: September 14, 2026.

This revision addresses the five findings in the review of the uploaded v9.
The corrected manuscript is `main.tex`; old uploaded text remains under
`originals/` for provenance. Earlier audit reports describe their own earlier
revisions, not the current PDF. The authoritative current build and provenance
records are `build_verification.json` and `provenance.json`.

## 1. The admissible-policy approximation proof

The former proof extended a feasible probability vector continuously across
merely measurable action-mask strata. This does not follow from the extension
theorem: singleton masks on opposite sides of a threshold can force a jump.
It also attempted to approximate logarithms on inadmissible actions where the
floored probability was still zero.

The corrected proof floors the target only on admissible actions and defines
bounded real scores on every action, assigning an arbitrary finite score to
inadmissible ones. Lusin's theorem is applied to the entire score vector under
the subprobability law of the current history and the Poisson-tail truncation.
On a common compact set the scores are continuous; bounded Tietze extensions
are then approximated by signature-linear functions. The actual, possibly
discontinuous mask is applied exactly after exponentiation. No globally
continuous feasible selector or logarithm of zero is required.

The hybrid construction proceeds forward. At each decision its approximation
measure is induced by the previously replaced rules. Taking the maximum of the
finitely many stage depths and padding with zeros does not change those rules
or laws. A common mismatch budget yields

\[
\Delta_{\Pi^N}\le\epsilon+KL(\rho_n+\delta+\alpha+b).
\]

This is an existential approximation bound. It is not an explicit generic
complexity rate in signature depth, nor an estimator of the class gap.

## 2. Complete observable history

The encoding now includes a finite initial-observation token, every observable
clock-report bundle, and the trader's own action/intervention records. The
initial token is an increment from a common origin, avoiding signature
translation invariance. Co-timestamped records retain their order. The
deterministic records are counted separately from the Poisson clock, and a
zero-event history still has its initial token.

For each fixed record string and length, the weakly ordered timestamp simplex
is compact and interpolation is continuous in 1-variation. The finite union is
compact. Terminal one-hot counts recover the length; nodes recover timestamps
and letters; a strictly increasing index coordinate supplies signature
separation. Policies use observed records, never the hidden uniformization
clock or its dummy marks.

The finite-book assumption now explicitly states nonempty Borel observable
masks, a finite initial observation, a common bounded loss, and remembered past
actions. Terminal feasibility remains a substantive model assumption.

## 3. Reference models and exogeneity

The reference is now a fully specified controlled model. The comparison includes
marked event-output differences, decision-time intervention error, same-path
loss discrepancy, and any uniform error in reducing the reference objective to
a surrogate. With event mismatch parameter gamma and intervention errors kappa,

\[
\beta_0=1-e^{-\Lambda\gamma T}\prod_k(1-\kappa_k),\qquad
\operatorname{regret}\le2D_0+2L\beta_0+2D_{\rm red}+\tau.
\]

A two-state counterexample shows that freezing an action label can give gamma
zero while the initial intervention leaves the reference feature law dependent
on that action. The corrected text supplies a sufficient autonomous-observable-
projection condition for exogeneity. A quadratic identity additionally requires
the exogenous feature, rate-cost, moment and feasibility assumptions of the
signature construction. Queue-dependent fills alone do not meet that identity.

## 4. Global optimization and numerical verification

The convergence corollary uses one fixed true objective and common state/action
spaces, encoding, initial law, report/decision maps and observable masks. The
optimization tolerance is a global objective gap. A one-step softmax example
has a Hessian of both signs, so generic convexity and local-residual claims were
removed. Fixed coefficient caps are not covered by the unrestricted class.

A new explicit finite-state proposition constructs depth-one logits from a
fully observed state indicator and a Bellman-optimal policy. If the preferred
action has logit r and others have logit zero, its uniform mismatch probability
is at most (|A|-1)/(exp(r)+|A|-1). The hybrid lemma yields the computable bound
min(L, KL(|A|-1)/(exp(r)+|A|-1)). This increases coefficient size, not depth, and
uses a finite-state optimization oracle rather than asserting a generic solver.

`scripts/feedback_checks.py` implements that construction and tests:

- 31 reconstructed transcripts, initial-state separation, and co-timestamped
  ordering at signature depth two;
- 1,260 finite-score, flooring and exact-mask comparisons;
- 14 depth-one policies in the 19-state book;
- 1,064 state/stage optimization comparisons and 1,064 consecutive-hybrid
  comparisons using the laws induced by earlier replacements;
- the frozen-mode counterexample, softmax nonconvexity, and 256 finite-policy
  comparisons with an autonomous reference model.

The new table is generated from the same JSON as the calculations. The complete
numerical reproduction command includes these checks. Numerical checks support
the finite examples; they are not a formal verification of the general proofs,
an implementation of the abstract Lusin construction, or market evidence.

## 5. Prior work and package integrity

The comparison now includes Bank, Bayer, Hager, Riedel and Nauen, *Stochastic
Control with Signatures*, SIAM Journal on Control and Optimization 63(5),
3189-3218 (2025), DOI 10.1137/24M1667671. Their signature-control density and
optimal-value results are explicitly distinguished from the finite-action,
partially observed marked-book specialization here. The published bibliographic
details were checked against the publisher, and the theorem locations against
the author manuscript. This revision makes no blanket foundational-priority
claim relative to that work, Kalsi et al., or Cont et al.

The abstract, introduction and conclusion reflect the corrected scope. Current
page counts, hashes, references, build findings and numerical provenance are
regenerated from the delivered files. `scripts/check_package.py` verifies the
manifest without modifying anything. Run it before rebuilding, since fresh PDF
metadata or regenerated files can legitimately change their byte hashes.
