# Market Microstructure Trilogy — Paper I

**The Mathematics of Market Impact and Order Execution**  
DOI: <https://doi.org/10.5281/zenodo.22736805>  
Fixed manuscript date: **15 September 2026**

The main document is `main.tex`. Run `latexmk -pdf main.tex` to perform the
required pdfLaTeX passes. All 11 PNG figures and every section and table
dependency required to compile the deposited PDF are included.

`Trilogy_Citations.bib` contains the definitive BibTeX records for all three
papers. The trilogy uses a fixed star citation architecture: Papers II and III
cite Paper I; Papers II and III do not cite one another.
